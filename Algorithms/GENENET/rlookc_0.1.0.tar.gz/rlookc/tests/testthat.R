library(testthat)
library(rlookc)

test_check("rlookc")
